<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!-- Google Analytics Content Experiment code -->
<script>function utmx_section(){}function utmx(){}(function(){var
k='106044321-1',d=document,l=d.location,c=d.cookie;
if(l.search.indexOf('utm_expid='+k)>0)return;
function f(n){if(c){var i=c.indexOf(n+'=');if(i>-1){var j=c.
indexOf(';',i);return escape(c.substring(i+n.length+1,j<0?c.
length:j))}}}var x=f('__utmx'),xx=f('__utmxx'),h=l.hash;d.write(
'<sc'+'ript src="'+'http'+(l.protocol=='https:'?'s://ssl':
'://www')+'.google-analytics.com/ga_exp.js?'+'utmxkey='+k+
'&utmx='+(x?x:'')+'&utmxx='+(xx?xx:'')+'&utmxtime='+new Date().
valueOf()+(h?'&utmxhash='+escape(h.substr(1)):'')+
'" type="text/javascript" charset="utf-8"><\/sc'+'ript>')})();
</script><script>utmx('url','A/B');</script>
<!-- End of Google Analytics Content Experiment code -->


<link rel="icon" type="image/png" href="/favicon.ico" />


<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Скала, бут, щебень, отсев, песок в Нижнем Тагиле недорого</title>
<link href="img/style.css" rel="stylesheet" type="text/css" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>

    <script src="http://atl-nt.ru/special/jquery.inputmask.js" type="text/javascript"></script>
    <script src="http://atl-nt.ru/special/jquery.inputmask.extensions.js" type="text/javascript"></script>
    <script src="http://atl-nt.ru/special/jquery.inputmask.date.extensions.js" type="text/javascript"></script>
    <script src="http://atl-nt.ru/special/jquery.inputmask.numeric.extensions.js" type="text/javascript"></script>
    <script src="http://atl-nt.ru/special/jquery.inputmask.custom.extensions.js" type="text/javascript"></script>



</head>
<script>
function show_form(text1,text2,button) {
		$('.modal_win h2').text(text1);
		$('.modal_win h3').text(text2);
		$('#zakaz_but').val(button);
		$('#text_zakaza').val(text2);
		$('.modal_win').show(100);
		}

     $(document).ready(function () {
			$("#phone").inputmask("+7(999)9999999");
			$("#tel2").inputmask("+7(999)9999999");
			$("#tel_z").inputmask("+7(999)9999999");

        });

</script>
<body>

<div class="main_screen">
<div class="main_screen_dot" align="center">
<h1>БУТ, ЩЕБЕНЬ, ОТСЕВ, ПЕСОК<br />
<span>ЗА 2 ЧАСА СО СКИДКОЙ 14% И ЦЕНОЙ от 230 РУБ. ЗА ТОННУ</span><br />
<em style="font-size:16px;">всегда в наличии на собственном складе</em>
</h1>
<div style="color:#FFFF00;">БЕСПЛАТНАЯ ДОСТАВКА ДО <?php echo date('d.m.Y',time()+86400); ?></div>
ПО НИЖНЕМУ ТАГИЛУ — ТОРОПИСЬ!


</div>

</div>

<div class="logo"><img src="img/logo.png" border="0" /><br />
Тяжёлое — легко!</div>

<div class="zvoni">
ЗВОНИ ПРЯМО СЕЙЧАС:<br />
+7 (3435) <span>92-29-92</span><br />
<div class="but_callback" onclick="show_form('Позвони нам БЕСПЛАТНО', 'Заказ обратного звонка','Позвонить бесплатно');" style="cursor:pointer;">Позвони нам бесплатно!</div>
</div>


<div class="zakaz">
<div class="fast_zak">БЫСТРЫЙ ЗАКАЗ</div>
<span>Заполни форму прямо сейчас и получи <em style="color:#FFFF00;">лучшее предложение</em> <br />
по нерудным материалам</span><br />
<form action="zakaz.php" method="post">
<input name="tel" id="tel_z" type="text" style="margin-right:10px;" placeholder="Номер телефона*" required="required" />
<img src="img/arr.png" width="100" height="156" class="arr" />
<input name="send" type="submit" value="ЗАКАЗАТЬ СЕЙЧАС" /></form><br />
<span style="font-size:9px;">* Данные используются только для звонка и НЕ будут переданы третьим лицам.</span>
</div>


<div class="priem">
<h2 style="color:#FFFFFF;margin-top:-20px;margin-bottom:50px;text-shadow: 0px 0px 10px rgba(0, 0, 0, 1);">ФАКТЫ О АВТОТРАНС ЛОГИСТИКА</h2>

<div class="div960" style="width:1100px;">
<div class="pokazatel" style="margin-top:-50px;"><span>2 <span style="font-size:60%;">часа</span></span><br />
 время доставки</div>

<div class="pokazatel" style="margin-top:-10px;"><span>12+</span><br />
лет на рынке</div>

<div class="pokazatel" ><span>-14%</span><br />
цены ниже среднерыночных</div>

<div class="pokazatel" style="margin-top:-10px;"><span>94%</span><br />
клиентов заказывают повторно</div>

<div class="pokazatel" style="margin-top:-50px;"><span>460+</span><br />
тысяч тонн доставлено</div>
<div style="clear:both;"></div>
</div>
</div>

<div class="gruzim">
<table width="150%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="66%"><img src="img/gruz2.jpg" /></td>
    <td width="34%"><h3>Грузим больше, <br />
чем заявлено!</h3></td>
  </tr>
</table>
<br />
<br />


</div>




<div align="center" style="margin-top:100px;">
<h2 style="margin-top:100px;">7 причин заказать у нас</h2>

<table width="960" border="0" cellspacing="0" cellpadding="10">
  <tr>
    <td width="200" align="center" valign="top"><img src="img/ddd1.jpg" width="150" height="150" /></td>
    <td width="200" align="center" valign="top"><img src="img/ddd2.jpg" width="150" height="150" /></td>
    <td width="200" align="center" valign="top"><img src="img/ddd3.jpg" width="150" height="150" /></td>
    <td width="200" align="center" valign="top"><img src="img/ddd4.jpg" width="150" height="150" /></td>
  </tr>
  <tr>
    <td align="center" valign="top"><strong>1. Лучшая цена на рынке</strong></td>
    <td align="center" valign="top"><strong>2. Собственный парк <br />
      на 15 машин</strong></td>
    <td align="center" valign="top"><strong>3. На рынке 12 лет</strong></td>
    <td align="center" valign="top"><strong>4. Высокое качество</strong></td>
  </tr>
</table>
<br />
<table width="720" border="0" cellspacing="0" cellpadding="10">
  <tr>
    <td width="200" align="center" valign="top"><img src="img/ddd5.jpg" width="150" height="150" /></td>
    <td width="200" align="center" valign="top"><img src="img/ddd6.jpg" width="150" height="150" /></td>
    <td width="200" align="center" valign="top"><img src="img/ddd7.jpg" width="150" height="150" /></td>
  </tr>
  <tr>
    <td align="center" valign="top"><strong>5. Более 1000 <br />
      довольных клиентов</strong></td>
    <td align="center" valign="top"><strong>6. Собственный склад <br />
      на 30000 тонн</strong></td>
    <td align="center" valign="top"><strong>7. Быстрое время доставки: от 2-х часов</strong></td>
  </tr>
</table>
</div>



<div class="materials" style="margin-top:100px;">
<h2>НАША ПРОДУКЦИЯ И ЦЕНЫ <br />
для заказа звоните +7 (3435) 92-29-92 или +7 (912) 24-69-500
</h2>

<div class="mat_info" align="center">
  <img src="img/v1.png"/><br />
<strong>БУТ, СКАЛА</strong><br />
от <span style="text-decoration:line-through;">290</span> 250 руб. за тонну
<div class="zakaz_mat" align="center" onclick="show_form('Оформление заказа', 'Заказ бута, скалы','Заказать бут, скалу сейчас');" style="cursor:pointer;">Заказать сейчас</div>
<div class="zakaz_mat5" align="center" onclick="show_form('Запрос на цену', 'Запрашиваю оптовую цену бута, скалы','Узнать цену бута, скалы сейчас');" style="cursor:pointer;">Узнать оптовую цену</div>
<br />

<div align="left">
<div class="tovar">Бут горный <a onclick="show_form('Оформление заказа', 'Заказ бута горного','Заказать бут горный');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Бут шлаковый <a onclick="show_form('Оформление заказа', 'Заказ бута шлакового','Заказать бут шлаковый');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Скала <a onclick="show_form('Оформление заказа', 'Заказ скалы','Заказать скалу');" style="cursor:pointer;">купить</a></div>
<div class="tovar">ПГС <a onclick="show_form('Оформление заказа', 'Заказ песка КРЗ','Заказать песок КРЗ');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Гравий <a onclick="show_form('Оформление заказа', 'Заказ гравия','Заказать гравий');" style="cursor:pointer;">купить</a></div>
</div>
</div>

<div class="mat_info" align="center">
  <img src="img/v2.png"/><br />
<strong>ЩЕБЕНЬ</strong><br />
от <span style="text-decoration:line-through;">270</span> 230 руб. за тонну
<div class="zakaz_mat" align="center" onclick="show_form('Оформление заказа', 'Заказ щебня','Заказать щебень сейчас');" style="cursor:pointer;">Заказать сейчас</div>
<div class="zakaz_mat5" align="center" onclick="show_form('Запрос на цену', 'Запрашиваю оптовую цену щебня','Узнать цену щебня сейчас');" style="cursor:pointer;">Узнать оптовую цену</div>
<br />

<div align="left">
<div class="tovar">Щебень горный фр.0-5 <a onclick="show_form('Оформление заказа', 'Заказ щебня горного фр.0-5','Заказать щебень фр.0-5');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Щебень горный фр.0-10 <a onclick="show_form('Оформление заказа', 'Заказ щебня горного фр.0-10','Заказать щебень фр.0-10');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Щебень горный фр.3-10 <a onclick="show_form('Оформление заказа', 'Заказ щебня горного фр.3-10','Заказать щебень фр.3-10');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Щебень горный фр.5-20 <a onclick="show_form('Оформление заказа', 'Заказ щебня горного фр.5-20','Заказать щебень фр.5-20');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Щебень горный фр.20-40 <a onclick="show_form('Оформление заказа', 'Заказ щебня горного фр.20-40','Заказать щебень фр.20-40');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Щебень горный фр.40-70 <a onclick="show_form('Оформление заказа', 'Заказ щебня горного фр.40-70','Заказать щебень фр.40-70');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Щебень шлаковый фр.5-20 <a onclick="show_form('Оформление заказа', 'Заказ щебня шлакового фр.5-20','Заказать щебень фр.5-20');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Щебень шлаковый фр.20-40 <a onclick="show_form('Оформление заказа', 'Заказ щебня шлакового фр.20-40','Заказать щебень фр.20-40');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Щебень шлаковый фр.40-70 <a onclick="show_form('Оформление заказа', 'Заказ щебня шлакового фр.40-70','Заказать щебень фр.40-70');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Щебень шлаковый фр.70-120 <a onclick="show_form('Оформление заказа', 'Заказ щебня шлакового фр.70-120','Заказать щебень фр.70-120');" style="cursor:pointer;">купить</a></div>
</div>
</div>

<div class="mat_info" align="center">
  <img src="img/v3.png"/><br />
<strong>ОТСЕВ</strong><br />
от <span style="text-decoration:line-through;">460</span> 400 руб. за тонну
<div class="zakaz_mat" align="center" onclick="show_form('Оформление заказа', 'Заказ отсева','Заказать отсев сейчас');" style="cursor:pointer;">Заказать сейчас</div>

<div class="zakaz_mat5" align="center" onclick="show_form('Запрос на цену', 'Запрашиваю оптовую цену отсева','Узнать цену отсева сейчас');" style="cursor:pointer;">Узнать оптовую цену</div>

<br />

<div align="left">
<div class="tovar">Отсев гранитный <a  onclick="show_form('Оформление заказа', 'Заказ отсева гранитного','Заказать отсев гранитный');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Отсев шлаковый <a  onclick="show_form('Оформление заказа', 'Заказ отсева шлакового','Заказать отсев шлакового');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Отсев горный <a  onclick="show_form('Оформление заказа', 'Заказ отсева горного','Заказать отсев горный');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Отсев зеленый <a  onclick="show_form('Оформление заказа', 'Заказ отсева зеленого','Заказать отсев зеленый');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Семечка <a  onclick="show_form('Оформление заказа', 'Заказ семечки','Заказать семечку');" style="cursor:pointer;">купить</a></div>
</div>
</div>

<div class="mat_info" align="center">
  <img src="img/v4.png"/><br />
<strong>ПЕСОК</strong><br />
от <span style="text-decoration:line-through;">460</span> 400 руб. за тонну
<div class="zakaz_mat" align="center" onclick="show_form('Оформление заказа', 'Заказ песка','Заказать песок сейчас');" style="cursor:pointer;">Заказать сейчас</div>
<div class="zakaz_mat5" align="center" onclick="show_form('Запрос на цену', 'Запрашиваю оптовую цену песка','Узнать цену песка сейчас');" style="cursor:pointer;">Узнать оптовую цену</div>
<br />

<div align="left">
<div class="tovar">Песок КРЗ <a onclick="show_form('Оформление заказа', 'Заказ песка КРЗ','Заказать песок КРЗ');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Песок серо-зеленый <a onclick="show_form('Оформление заказа', 'Заказ песка серо-зеленого','Заказать песок серо-зеленый');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Песок речной крупный <a onclick="show_form('Оформление заказа', 'Заказ песка речного крупного','Заказать песок речной крупный');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Песок речной мелкий <a onclick="show_form('Оформление заказа', 'Заказ песка речного мелкого','Заказать песок речной мелкий');" style="cursor:pointer;">купить</a></div>
<div class="tovar">Песок шлаковый <a onclick="show_form('Оформление заказа', 'Заказ песка шлакового','Заказать песок шлаковый');" style="cursor:pointer;">купить</a></div>
</div>
</div>


<div style="clear:both;"></div>
</div>





<div class="dopinfo" align="center">

<table width="960" border="0" cellpadding="0" cellspacing="0" style="">
  <tr>
    <td><div class="dopinfo_detail">
<h3><img src="img/b1.png" width="83" height="130" />Доставка до удобного места</h3>
Наши водители доставляют материалы до самого удобного для Вас места, чтобы был удобный подход.
</div></td>
    <td><div class="dopinfo_detail">
<h3><img src="img/b2.png" width="83" height="130" />Сертификаты и соответствие ГОСТу</h3>
Вся наша продукция имеет сертификаты и соответствует ГОСТу.
</div></td>
  </tr>
  <tr>
    <td><div class="dopinfo_detail">
<h3><img src="img/b3.png" width="83" height="130" />Контроль качества</h3>
Наши специалисты постоянно следать за качеством материалов, а также за соблюдением размеров фракций.
</div></td>
    <td><div class="dopinfo_detail">
<h3><img src="img/b4.png" width="83" height="130" />Опытные, профессиональные водители</h3>
У нас работают исключительно опытные и профессиональные водители с большим стажем работы.
</div></td>
  </tr>
</table>










</div>

<div style="clear:both;"></div>


<br /><br />
<br />
<br />

<div class="extra_info">
<img src="img/ex_in1.jpg" width="384" height="200" style="float:left;margin-right:30px;" />
<h3 style="font-size:120%;">Выгодное качество — это просто!</h3>
Наши <strong>цены</strong> практически <strong>самые низкие</strong> на рынке, даже ниже чем у производителя (карьера). Дело не в хитрости и не в обмане. Всё гораздо проще! Мы закупаем материал тогда, когда его никто не покупает, а именно - зимой. В это время цены на нерудные материалы очень низки. А собственный склад материалов позволяет вместить более 30000 тонн. </div>
<div style="clear:both;"></div>
<br />
<br />
<br />
<br />



<div class="extra_info">
<img src="img/ex_in2.jpg" width="384" height="200" style="float:right;margin-left:30px;" />
<h3 style="font-size:120%;">Надежная техника — гарантия сроков!</h3>
Наш собственный парк техники насчитывает более 15 единиц. Туда входят самосвалы, фронтиальные погрузчики и трактор. Мы комплектуем парк <strong>исключительно иномарками</strong>, что позволяет быть полностью уверенными в сроках и надежности.<br />
<br />
<br />

</div>
<div style="clear:both;"><br />
<br /><br /></div>



<div align="center" style="margin-top:100px;">
<h2 style="margin-top:100px;">Так мы работаем</h2>


<div class="steps" align="center">
<table width="960" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td width="25%" align="center" valign="top"><img src="img/step1.png" width="120" height="120" /></td>
    <td width="25%" align="center" valign="top"><img src="img/step2.png" width="120" height="120" /></td>
    <td width="25%" align="center" valign="top"><img src="img/step3.png" width="120" height="120" /></td>
    <td width="25%" align="center" valign="top"><img src="img/step4.png" width="120" height="120" /></td>
  </tr>
  <tr style="font-size:18px;font-weight:bold;">
    <td align="center" valign="top">1. Заявка</td>
    <td align="center" valign="top">2. Загрузка</td>
    <td align="center" valign="top">3. Доставка</td>
    <td align="center" valign="top">4. Оплата</td>
  </tr>
  <tr>
    <td align="center" valign="top">Вы звоните по телефону <br />
      <strong>92-29-92</strong><br />
      или оставляете <br />
      <a onclick="show_form('Оформление заявки', 'Хочу сделать заказ','Сделать заказ');" style="cursor:pointer;text-decoration:underline;">заявку на сайте</a></td>
    <td align="center" valign="top">Обговарвиаем сроки. Мы подготавливаем машину, грузим и высылаем по Вашему адресу</td>
    <td align="center" valign="top">К Вам приходит машина с материалом и разгружается в удобном для Вас месте</td>
    <td align="center" valign="top">Вы оплачиваете материал и остаетесь довольны качеством сервиса</td>
  </tr>
</table>

</div>

</div>



<div align="center" style="margin-top:150px;">
<h2 style="margin-top:100px;">НАМ ДОВЕРЯЮТ</h2>
<img src="img/dover.jpg" style="width:100%;max-width:960px;" /></div>


<br />
<br />
<br /><br />
<br />
<br />

<br />


<div align="center" class="otziv">
<div class="otziv2">
<h2 style="">ОТЗЫВЫ О НАС</h2>

<div class="otziv_one">
  <img src="img/otz1.jpg" />
<strong>Щетинин Евгений<br />
<span>Директор компании "Элит Монолит"</span></strong><br />
<br />
<span>"Мы занимаемся строительством монолитных коттеджей премиум класса. Для нас очень важны сроки поставок и стоимость материалов. В лице компании АТЛ мы нашли замечательного партнера, на которого можно положиться по срокам, а благодаря выгодным ценам наши клиенты довольны. Будем работать и дальше с Вами!"</span>
  </div>



<div class="otziv_one">
  <img src="img/otz2.jpg" />
<strong>Беляев Константин<br />
<span>Домовладелец</span></strong><br />
<br />
<span>"У меня свой дом в частном секторе ГГМ, я постоянно занимаюсь небольшим строителтьством. То пристрой надо сделать, то под баню фундамент. На Вашу компанию я попал случайно около 2-х лет назад. Меня устроили цены, а когда сделал заказ мне понравилось, что водители заботятся о том, чтобы мне меньше таскать приходилось и заезжали в те места, куда другие компании отказывались. Очень доволен работой Вашей компании."</span>
  </div>
  
  
  
  <div class="otziv_one">
  <img src="img/otz3.jpg" />
<strong>Хмельницкий Федор<br />
<span>ИП - производитель ЖБИ</span></strong><br />
<br />
<span>"Наши шлакоблоки славятся по всей области. От части это заслуга Вашей компании из-за качественных материалов. Особенно мне нравится то, что когда у других не получается привезти с карьера, то у Вас всегда есть на собственном складе. Благодаря Вам мои работники не простаивают. Спасибо что выручаете!"</span>
  </div>


<div style="clear:both;">
Работаете с нами? Напишите о нас отзыв прямо сейчас на электронную почту atl-nt@mail.ru и мы опубликуем его на сайте. <br />
<strong>Спасибо, что рекомендуете нас! </strong><br />
  <br />
</div>
</div></div>



<div align="center" style="display:none;">
<h2 style="margin-top:100px;">ОТЗЫВЫ О НАС</h2>

</div>



<div align="center">
<h2 style="margin-top:100px;">СВЯЖИТЕСЬ С НАМИ</h2><br />
<br />



<table border="0" cellspacing="0" cellpadding="0" class="contact_info">
  <tr>
    <td><table width="320" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="55" height="55" rowspan="2" valign="top"><img src="img/k1.jpg" width="50" height="50" /></td>
    <td align="left" valign="top"><span>ПО ТЕЛЕФОНУ:</span></td>
  </tr>
  <tr>
    <td align="left" valign="top"><span>+7 (3435) </span><strong>92-29-92</strong><br />
<span>+7 (912) </span><strong>24-69-500</strong>

</td>
  </tr>
</table></td>
    <td><table width="320" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="55" height="55" rowspan="2" valign="top"><img src="img/k2.jpg" width="50" height="50" /></td>
    <td align="left" valign="top"><span>ПО ЭЛЕКТРОННОЙ ПОЧТЕ:</span></td>
  </tr>
  <tr>
    <td align="left" valign="top"><strong>atl-nt@mail.ru</strong><br />


</td>
  </tr>
</table></td>
    <td><table width="320" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="55" height="55" rowspan="2" valign="top"><img src="img/k3.jpg" width="50" height="50" /></td>
    <td align="left" valign="top"><span>ПО АДРЕСУ:</span></td>
  </tr>
  <tr>
    <td align="left" valign="top"><strong>Нижний Тагил, ул.Черных 79а</strong><br />


</td>
  </tr>
</table></td>
  </tr>
</table>




<div style="margin:15px;font-weight:bold;">ИЛИ</div>

оставь свой номер и менеджер <br />
позвонит в течении <strong>15 минут</strong><br />
<br />
<form action="zakaz.php" method="post">
<input name="tel" id="tel2" type="text" style="margin-right:10px;padding:7px;" placeholder="Номер телефона*" required="required" /><input name="send" type="submit" value="Перезвоните мне!" style="padding:7px;" /></form>

<span style="font-size:60%;">* Ваш номер используется только для звонка и НЕ передается третьим лицам</span>

</div>



<div align="center">
<h2 style="margin-top:100px;">МЫ НА КАРТЕ</h2>

<section id="map">
	
<script type="text/javascript" charset="utf-8" src="https://api-maps.yandex.ru/services/constructor/1.0/js/?sid=ClpxmoO8opkPmz6HwdmSSROhMBeAm-ux&height=450"></script>
</section>


</div>




<div align="center" style="background-color:#000000;padding:50px;color:#FFFFFF;">

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="left" valign="top"><strong>ООО «АТЛ»</strong><br />
ИНН: 6623091582<br />
КПП: 662301001</td>
    <td align="right" valign="top"><img src="img/logo.png" height="80"  style="float:right;margin-left:15px;"/>Бут, щебень, отсев, песок с доставкой в Нижнем Тагиле<br />
    Copyright 2015 © ATL-NT.RU<br />
Все права защищены.<br />
Копирование контента сайта запрещено!<br />
<a href="http://energenius.ru" target="_blank"><img src="http://energenius.ru/img/logo/footer_logo_(site_dev)_white.png" width="250" border="0" style="margin-top:15px;"></a>
</td>
  </tr>
</table>

</div>


<div class="modal_win">
<div class="form_zakaz">
<div class="close_modal"><a onclick="$('.modal_win').hide(100);" style="cursor:pointer;">[X] закрыть</a></div>
<h2>Позвоните нам БЕСПЛАТНО</h2>
<h3>Заказ обратного звонка</h3>
<form action="zakaz.php" method="post">
<input name="text_zakaza" id="text_zakaza" type="hidden" value="" />
<input name="tel" id="phone" type="text" placeholder="Ваш номер телефона" required="required" />
<input name="zakaz" id="zakaz_but" type="submit" value="Позвонить бесплатно" /></form>
<br />
<span style="font-size:70%;">* введенные данные будут использованы только для звонка и НЕ будут переданы третьим лицам</span>

</div>
</div>



<!-- Yandex.Metrika counter -->
<script type="text/javascript">
    (function (d, w, c) {
        (w[c] = w[c] || []).push(function() {
            try {
                w.yaCounter31689096 = new Ya.Metrika({
                    id:31689096,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true,
                    webvisor:true
                });
            } catch(e) { }
        });

        var n = d.getElementsByTagName("script")[0],
            s = d.createElement("script"),
            f = function () { n.parentNode.insertBefore(s, n); };
        s.type = "text/javascript";
        s.async = true;
        s.src = "https://mc.yandex.ru/metrika/watch.js";

        if (w.opera == "[object Opera]") {
            d.addEventListener("DOMContentLoaded", f, false);
        } else { f(); }
    })(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/31689096" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->



</body>
</html>