<div style="width:100%;margin-top:100px;" align="center">
<h1>
Контакты с АвтоТранс Логистика
</h1>
<table border="0" cellpadding="10" cellspacing="0" style="width:100%;max-width:1280px;">
  <tr>
     <td width="30%" align="left" valign="top"><img src="img/l4.jpg" style="width:100%;" border="0"></td>
    <td align="left" valign="top">
    
    Свяжитесь с нашей компанией любым из удобных для Вас способов. <br />
    <br />
    <table width="100%" border="0" cellpadding="10" cellspacing="0">
      <tr>
        <td width="50"><img src="img/x1.jpg" width="50" height="50" border="0" /></td>
        <td><strong>По телефону:</strong><br />
          +7 (3435) 92-29-92<br />
          +7 (912) 24-69-500</td>
      </tr>
      <tr>
        <td><img src="img/x2.jpg" width="50" height="50" border="0" /></td>
        <td><strong>По электронной почте:</strong><br />
          <a href="mailto:atl-nt@mail.ru">atl-nt@mail.ru</a></td>
      </tr>
      <tr>
        <td><img src="img/x3.jpg" width="50" height="50" border="0" /></td>
        <td><strong>Оставте заявку на сайте:</strong><br />
          <a href="#" onclick="$('#h1').html('ОСТАВТЕ ЗАЯВКУ');$('.modal_zayavka').show(100);return(false);">Оставить заявку</a></td>
      </tr>
      <tr>
        <td><img src="img/x4.jpg" width="50" height="50" border="0" /></td>
        <td><strong>Хотите, перезвоним Вам?</strong><br />
           <a href="#" onclick="$('#h1').html('ПЕРЕЗВОНИТЕ МНЕ');$('.modal_zayavka').show(100);return(false);">Перезвоните мне</a></td>
      </tr>
      <tr>
        <td><img src="img/x5.jpg" width="50" height="50" border="0" /></td>
        <td><strong>Приезжайте к нам в офис:</strong><br />
          г.Нижний Тагил, ул.Черных 79а</td>
      </tr>
    </table></td>
  </tr>
</table>

</div>