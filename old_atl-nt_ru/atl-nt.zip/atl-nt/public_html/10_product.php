<div style="margin-top:100px;" align="center">
<h2>Наша продукция</h2>
<table style="width:100%;max-width:1280px;"  border="0">
  <tr>
    <td width="33%" align="center" valign="top" class="wow flipInY" data-wow-delay="0.4s"><img src="img/v1.png" style="width:80%;" /></td>
    <td align="center" valign="top" class="wow flipInY" data-wow-delay="0.8s"><img src="img/v2.png" style="width:80%;" /></td>
    <td width="33%" align="center" valign="top" class="wow flipInY" data-wow-delay="1.2s"><img src="img/v3.png" style="width:80%;" /></td>
  </tr>
  <tr class="pay_table">
    <td align="center" valign="top" class="wow zoomIn" data-wow-delay="1.4s"><span style="font-size:150%;">БУТ, СКАЛА</span> <a  class="buy" onclick="$('#h1').html('ЗАЯВКА НА БУТ ИЛИ СКАЛУ');$('.modal_zayavka').show(100);">ЗАКАЗАТЬ</a><br /><br />
    <span class="price">
   <span style="text-decoration:line-through;color:#CCCCCC;">от 290 руб/тн</span> от 250 руб/тн</span> 
    <br /><br />

горный, шлаковый, скала, ПГС, гравий
</td>
    <td align="center" valign="top" class="wow zoomIn" data-wow-delay="1.8s"><span style="font-size:150%;">ЩЕБЕНЬ</span>  <a  class="buy" onclick="$('#h1').html('ЗАЯВКА НА ЩЕБЕНЬ');$('.modal_zayavka').show(100);">ЗАКАЗАТЬ</a><br /><br /><span class="price"><span style="text-decoration:line-through;color:#CCCCCC;">от 270 руб/тн</span> от 230 руб/тн </span><br />
    <br />
горный, шлаковый</td>
    <td align="center" valign="top" class="wow zoomIn" data-wow-delay="2.2s"><span style="font-size:150%;">ОТСЕВ</span>  <a  class="buy" onclick="$('#h1').html('ЗАЯВКА НА ОТСЕВ');$('.modal_zayavka').show(100);">ЗАКАЗАТЬ</a><br /><br /><span class="price">
    <span style="text-decoration:line-through;color:#CCCCCC;">от 460 руб/тн</span> от 400 руб/тн </span>
    <br /><br />
гранитный, шлаковый, горный, зеленый, семечка
</td>
  </tr>
</table>
<br />
<br />


<table style="width:66%;max-width:853px;" border="0">
  <tr>
    <td width="50%" align="center" valign="top" class="wow flipInY" data-wow-delay="0.4s"><img src="img/v4.png" style="width:80%;" /></td>
    <td align="center" valign="top" class="wow flipInY" data-wow-delay="0.8s"><img src="img/v5.png" style="width:80%;" /></td>
  </tr>
  <tr class="pay_table">
    <td align="center" valign="top" class="wow zoomIn" data-wow-delay="0.8s"><span style="font-size:150%;">ПЕСОК</span>  <a  class="buy" onclick="$('#h1').html('ЗАЯВКА НА ПЕСОК');$('.modal_zayavka').show(100);">ЗАКАЗАТЬ</a><br /><br /><span class="price">
    <span style="text-decoration:line-through;color:#CCCCCC;">от 460 руб/тн</span> от 400 руб/тн </span>
    <br /><br />
серо-зеленый, речной, шлаковый
</td>
    <td align="center" valign="top"  class="wow zoomIn" data-wow-delay="1.2s"><span style="font-size:150%;">ТОРФ</span>  <a   class="buy" onclick="$('#h1').html('ЗАЯВКА НА  ТОРФ');$('.modal_zayavka').show(100);">ЗАКАЗАТЬ</a><br /><br /><span class="price">
    <span style="text-decoration:line-through;color:#CCCCCC;">от 390 руб/тн</span> от 350 руб/тн </span>
    <br /><br />
верховой, низинный
</td>
  </tr>
</table>
</div>