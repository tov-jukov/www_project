<div align="center" style="margin-top:100px;">
<h2>Кто наши клиенты</h2>
<table style="width:100%;max-width:1280px;" border="0">
  <tr>
    <td width="33%" align="center" valign="top"><img src="img/who1.jpg" style="width:80%;max-width:217px;" /></td>
    <td align="center" valign="top"><img src="img/who2.jpg" style="width:80%;max-width:217px;" /></td>
    <td width="33%" align="center" valign="top"><img src="img/who3.jpg" style="width:80%;max-width:217px;" /></td>
  </tr>
  <tr>
    <td align="center" valign="top">Производственные предприятия<br />
и заводы</td>
    <td align="center" valign="top">Строительные организации<br />
и частные строители</td>
    <td align="center" valign="top">Частные домовладельцы<br />
и садоводы</td>
  </tr>
</table>

</div>