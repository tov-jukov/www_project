<div class="copyright" align="center">
<a href="#" style="color:#FFFF00;">Вернуться к началу</a><br />
<br />
<br />
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="left" valign="top"><strong>ООО «АТЛ»</strong><br />
ИНН: 6623091582<br />
КПП: 662301001</td>
    <td align="right" valign="top"><img src="img/atl_icon_white.png" height="80"  style="float:right;margin-left:15px;"/>Бут, щебень, отсев, песок с доставкой в Нижнем Тагиле<br />
    Copyright 2016 © ATL-NT.RU<br />
Все права защищены.<br />
Копирование контента сайта запрещено!<br /></td>
  </tr>
</table>
<br />
<br />
</div>