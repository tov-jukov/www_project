<div class="lg_div">
<a href="index.php"><img src="img/lg.png"  class="lg animated  fadeInDownBig" data-wow-delay="0.0s" border="0" /></a>
<table width="100%" border="0" cellspacing="5" class="lg_table">
  <tr>
    <td width="25%" class="wow fadeInDownBig" data-wow-delay="0.2s">
    <a href="company.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image3','','img/b1-2.png',1)"><img src="img/b1-1.png" name="Image3" style="width:100%;" border="0" id="Image3" /></a> </td>
    <td width="25%" class="wow fadeInDownBig" data-wow-delay="0.4s">
      <a href="products.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image4','','img/b2-2.png',1)"><img src="img/b2-1.png" name="Image4"  style="width:100%;" border="0" id="Image4" /></a></td>
    <td width="25%" class="wow fadeInDownBig" data-wow-delay="0.6s">
    <a href="arenda.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image5','','img/b3-2.png',1)"><img src="img/b3-1.png" name="Image5" style="width:100%;" border="0" id="Image5" /></a>
    </td>
    <td width="25%" class="wow fadeInDownBig" data-wow-delay="0.8s">
       <a href="contacts.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image6','','img/b4-2.png',1)"><img src="img/b4-1.png" name="Image6" style="width:100%;" border="0" id="Image6" /></a>
       </td>
  </tr>
</table>

</div>

<div class="tel_top wow fadeInDownBig" data-wow-delay="1.4s">
+7 (3435) 92-29-92<br />
+7 (912) 24-69-500
</div>