<div align="center">
<table border="0" cellpadding="0" cellspacing="0" style="width:100%;max-width:1280px;">
  <tr>
    <td width="25%" align="center"><img src="img/m1.jpg" style="width:80%;" class="wow fadeInRight" data-wow-offset="10" data-wow-delay="0.4s" /></td>
    <td width="25%" align="center"><img src="img/m2.jpg" style="width:80%;"  class="wow fadeInRight" data-wow-offset="10" data-wow-delay="0.8s" /></td>
    <td width="25%" align="center"><img src="img/m3.jpg" style="width:80%;"  class="wow fadeInRight" data-wow-offset="10" data-wow-delay="1.2s" /></td>
    <td width="25%" align="center"><img src="img/m4.jpg" style="width:80%;"  class="wow fadeInRight" data-wow-offset="10" data-wow-delay="1.6s" /></td>
  </tr>
  <tr style="font-size:80%;">
    <td align="center" style="padding:10px;"  class="wow fadeInUp" data-wow-offset="10" data-wow-delay="1.8s" >За все время работы компанией АТЛ было доставлено более <strong>450 тысяч тонн</strong> нерудных материалов на общее расстояние более <strong>340 тысяч километров.</strong></td>
    <td align="center" style="padding:10px;" class="wow fadeInUp" data-wow-offset="10" data-wow-delay="2.2s" >Мы стремимся максимально удовлетворить потребность клиентов. Именно по этому <strong>94 %</strong> клиентов <strong>рекомендуют</strong> нас друзьям и <strong>заказывают повторно</strong>.</td>
    <td align="center" style="padding:10px;" class="wow fadeInUp" data-wow-offset="10" data-wow-delay="2.6s" >Благодаря <strong>собственным складам</strong>, <strong>парку техники</strong> и <strong>налаженным связям</strong> цены на некоторую нашу продукцию<strong> дешевле среднерыночных на 13%</strong>.</td>
    <td align="center" valign="top" style="padding:10px;" class="wow fadeInUp" data-wow-offset="10" data-wow-delay="3s" >Наша деятельность началась в далеком <strong>1998 году</strong>, но как организация АТЛ мы появились в <strong>2004 году</strong> - <strong>12 лет надежности</strong> и <strong>ответственности</strong>.</td>
  </tr>
</table>
</div>