<div class="utp wow fadeInLeft" data-wow-delay="2s">
<div class="h1">
ПРОДАЕМ И ДОСТАВЛЯЕМ В НИЖНЕМ ТАГИЛЕ<br />
ЩЕБЕНЬ, БУТ, ОТСЕВ, ПЕСОК И ТОРФ ОТ 2 ТОНН
</div>
<div style="clear:both;"></div>
<div class="plus wow fadeInLeft" data-wow-delay="3.2s">✔ Выгодные цены</div><div class="plus wow fadeInLeft" data-wow-delay="2.8s">✔ Всегда в наличии</div><div class="plus wow fadeInLeft" data-wow-delay="2.4s">✔ Быстрая доставка</div>
</div>