<div style="margin-top:100px;" align="center">
<h2>География работы</h2>
<table style="width:100%;max-width:1280px;" border="0">
  <tr>
    <td align="left" valign="top"><img src="img/urfo.jpg" style="width:100%"  class="wow flipInX" data-wow-delay="0.8s"/></td>
    <td width="33%" align="left" valign="top" style="padding:15px;"><br />
<br />
<br />
Компания АвтоТранс Логистика работает <strong>по всему Уральскому Федеральному Округу</strong>, включая, но не ограничеваясь:<br />
<br />

✔ Свердловская область<br />
✔ Челябинская область<br />
✔ Курганская область<br />
✔ Тюменская область<br />
✔ ХМАО<br />
✔ ЯНАО<br />

</td>
  </tr>
</table>

</div>