<div id="from_grader">
  

  <div class="priem">
  
    <h2>ФАКТЫ О АВТОТРАНС ЛОГИСТИКС</h2>
    
    <div class="pokazatel"><span>2</span><br>
    часа - время доставки</div>
    
    <div class="pokazatel"><span>11+</span><br>
    лет на рынке</div>
    
    <div class="pokazatel"><span>-13%</span><br>
    цены ниже среднерыночных</div>
    
    <div class="pokazatel"><span>93%</span><br>
    клиентов заказывают повторно</div>
    
    <div class="pokazatel"><span>450+</span><br>
    тысяч тонн доставлено</div>
    
    <div style="clear:both;"></div>
  
  </div>
  
  <!-- ========================================== -->
  
  <div class="gruzim">
    
    <table width="150%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="66%"><img src="/img/grader/gruz2.jpg"></td>
        <td width="34%"><h3>Грузим больше, <br>
    чем заявлено!</h3></td>
      </tr>
    </table>
  
    <br>
    <br>
  
  </div>
  
  <!-- ========================================== -->
  
  <div class="dopinfo">
  
    <div class="dopinfo_detail">
    <h3><img src="/img/grader/b1.jpg" width="100" height="150">Доставка до удобного места</h3>
    Наши водители доставляют материалы до самого удобного для Вас места, чтобы подход был прост и удобен.
    </div>
    
    <div class="dopinfo_detail">
    <h3><img src="/img/grader/b2.jpg" width="100" height="150">Сертификаты и соответствие ГОСТ</h3>
    Вся наша продукция имеет сертификаты и соответствует ГОСТ.
    </div>
    
    <div class="dopinfo_detail">
    <h3><img src="/img/grader/b3.jpg" width="100" height="150">Контроль качества</h3>
    Наши специалисты постоянно следят за качеством материалов и соблюдением размеров фракций.
    </div>
    
    <div class="dopinfo_detail">
    <h3><img src="/img/grader/b4.jpg" width="100" height="150">Опытные, профессиональные водители</h3>
    У нас работают исключительно опытные и профессиональные водители с большим стажем работы.
    </div>
  
    <div style="clear:both;"></div>
  
  </div>
  
  <!-- ========================================== -->
  
  <div align="center">
    <h2 style="margin-top:100px;">НАМ ДОВЕРЯЮТ</h2>
    <img src="/img/grader/dover.jpg" style="width:100%;max-width:960px;">
  </div>
  
  <!-- ========================================== -->
  
  <div align="center" style="display:none;">
    <h2 style="margin-top:100px;">ОТЗЫВЫ О НАС</h2>
  </div>
  
  <!-- ========================================== -->
  
  <div align="center">
  
    <h2 style="margin-top:100px;">СВЯЖИТЕСЬ С НАМИ</h2><br>
    <br>  
    
    <table border="0" cellspacing="0" cellpadding="0" class="contact_info">
      <tr>
        <td>
          <table width="320" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="55" height="55" rowspan="2" valign="top"><img src="/img/grader/k1.jpg" width="50" height="50"></td>
              <td align="left" valign="top"><span>ПО ТЕЛЕФОНУ:</span></td>
            </tr>
            <tr>
              <td align="left" valign="top"><span>+7 (3435) </span><strong>92-29-92</strong><br>
                <span>+7 (912) </span><strong>24-69-500</strong>
              </td>
            </tr>
          </table>
        </td>
        <td>
          <table width="320" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="55" height="55" rowspan="2" valign="top"><img src="/img/grader/k2.jpg" width="50" height="50"></td>
              <td align="left" valign="top"><span>ПО ЭЛЕКТРОННОЙ ПОЧТЕ:</span></td>
            </tr>
            <tr>
              <td align="left" valign="top">
                <strong>atl-nt@mail.ru</strong><br>
              </td>
            </tr>
          </table>
        </td>
        <td>
          <table width="320" border="0" cellpadding="0" cellspacing="0">
            <tr>
             <td width="55" height="55" rowspan="2" valign="top"><img src="/img/grader/k3.jpg" width="50" height="50"></td>
             <td align="left" valign="top"><span>ПО АДРЕСУ:</span></td>
            </tr>
            <tr>
              <td align="left" valign="top"><strong>Нижний Тагил, ул.Черных 79а</strong><br></td>
            </tr>
          </table>
        </td>
      </tr>
    </table>  
    
    <p style="margin: 10px auto;">ИЛИ</p>
    
    оставьте свой номер и менеджер <br>
    свяжется с вами в течении <strong>15 минут</strong><br>
    <br>
    <form action="send.php" method="post">
      <input name="tel" type="text" style="margin-right:10px;padding:7px;" placeholder="Номер телефона*" id="recall">
      <input type="hidden" name="key" value="<?=$_SESSION['key_a']?>">
      <input name="send" type="submit" value="Перезвоните мне!" id="_callback" disabled="disabled">
    </form>
    
    <span style="font-size:60%;">* Ваш номер используется только для звонка и НЕ передается третьим лицам</span>
  
  </div>
  
  <!-- ========================================== -->

  <div align="center">
   
    <h2 style="margin-top:100px;">МЫ НА КАРТЕ</h2>
    
    <div id="map">
      
    <script type="text/javascript" charset="utf-8" src="https://api-maps.yandex.ru/services/constructor/1.0/js/?sid=ClpxmoO8opkPmz6HwdmSSROhMBeAm-ux&height=450"></script>
    </div>
  
  </div>
  
  <!-- ========================================== -->

  <div align="center" style="background-color:#000000;padding:50px;color:#FFFFFF;">
  
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="left" valign="top">&nbsp;</td>
        <td align="right" valign="top"><img src="/img/grader/logo.png" height="80"  style="float:right;margin-left:15px;">Бут, щебень, отсев, песок с доставкой в Нижнем Тагиле<br>
        Copyright 2015 © ATL-NT.RU<br>
        Все права защищены.<br>
        Копирование контента сайта: запрещено!<br>
    <a href="http://energenius.ru" target="_blank"><img src="http://energenius.ru/img/logo/footer_logo_(site_dev)_white.png" width="250" border="0" style="margin-top:15px;"></a>
    </td>
      </tr>
    </table>
  
  </div>

</div>
