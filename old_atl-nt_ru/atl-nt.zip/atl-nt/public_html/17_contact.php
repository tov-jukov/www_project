<div style="margin-top:100px;padding-top:50px;background-color:#a70000;color:#FFFFFF;" align="center">
<h2>Свяжитесь с нами</h2>
<table border="0" cellpadding="15" cellspacing="0" style="width:100%;max-width:1280px;">
  <tr>
    <td width="10%" align="center" valign="top"><img src="img/c1.png" style="width:100%;" border="0" /></td>
    <td width="23%" align="left" valign="top"><strong>По телефону:</strong><br />
      <br />
<span style="font-size:130%;">+7 (3435) 92-29-92<br />
+7 (912) 24-69-500</span>
</td>
    <td width="10%" align="center" valign="top"><img src="img/c2.png" style="width:100%;" border="0" /></td>
    <td width="23%" align="left" valign="top"><strong>По электропочте:</strong><br />
      <br />
      <span style="font-size:130%;"><a href="mailto:atl-nt@mail.ru" style="color:#FFFFFF;">atl-nt@mail.ru</a></span></td>
    <td width="10%" align="center" valign="top"><img src="img/c3.png" style="width:100%;" border="0" /></td>
    <td width="23%" align="left" valign="top"><strong>Оставте заявку:</strong><br />
      <br />
<a href="#"  onclick="$('#h1').html('СВЯЖИТЕСЬ СО МНОЙ');$('.modal_zayavka').show(100);return(false);" style="color:#FFFFFF;">Оставте свой номер телефона</a> и мы сами свяжемся с Вами в рабочее время.
</td>
  </tr>
</table>
<h2>Приезжайте к нам</h2>
<section id="map">
	
<script type="text/javascript" charset="utf-8" src="https://api-maps.yandex.ru/services/constructor/1.0/js/?sid=ClpxmoO8opkPmz6HwdmSSROhMBeAm-ux&height=450"></script>
</section>
</div>