<div class="form wow fadeInUp" data-wow-delay="3.2s" align="center">
<div class="strong wow fadeInUp" data-wow-delay="3.6s"><strong>СКИДКА 6% - ТОЛЬКО СЕЙЧАС</strong></div><br />
<span class="wow fadeInUp" data-wow-delay="4s">Получите скидку 6% прямо сейчас! Введите свой номер телефона и нажмите заказать. Наш оператор свяжется с вами для уточнения заказа.</span><br />
<br />
<form action="spasibo.php" method="post"><input name="tel" id="tel" class="tel wow fadeInUp" data-wow-delay="4.4s" type="text" required placeholder="Введите номер телефона">
  <br>
  <input name="submit" class="submit wow fadeInUp" data-wow-delay="4.8s" type="submit" value="Заказать и получить скидку 6%">
   
</form><br />
<span style="font-size:50%;" class="wow fadeInUp" data-wow-delay="5s">* Мы не передадим Ваш номер телефона третьим лицам!<br />
<a href="#" onClick="$('#policy').show();return(false);">политика конфидициальности</a>
</span>

<script>
 var tl = new Date('<?php echo date('Y/m/d',time()+86300); ?> 00:00:00');
 </script>
<div class="container wow fadeInUp" data-wow-delay="5.4s">
    <div id="CDT"></div>
  </div>
  
  
  
</div>