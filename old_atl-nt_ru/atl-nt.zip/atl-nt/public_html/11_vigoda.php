<div class="sklad" align="center" style="margin-top:100px;">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td class="sklad_img">&nbsp;</td>
    <td width="30%" style="padding:30px;background-color:#999999;color:#FFFFFF;"><h2>Всегда в наличии</h2>
    Благодаря собственным складам и огромным запасам нерудных материалов мы осуществляем отгрузку и доставку без задержек. <br />
<br />
Вы можете сами убедиться, что АТЛ -  компания-партнер №1 в Нижнем Тагиле.
    <br />
<br />
<a onclick="$('#h1').html('ЗАПИСАТЬСЯ НА ЭКСКУРСИЮ');$('.modal_zayavka').show(100);" class="excurs">Записаться на экскурсию</a>
    <br />
<br />
<br />

    </td>
  </tr>
</table>

</div>






<div class="sklad" align="center" style="">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="30%" style="padding:30px;background-color:#999999;color:#FFFFFF;"><h2>Успеем вовремя</h2>
    Огромный парк собственной техники (самосвалов и погрузчиков) дает уверенность в сроках поставки, а нажедность импортной техники дает гарантию осутствия простоев.<br />
<br />
Вы можете сами убедиться, что АТЛ -  компания-партнер №1 в Нижнем Тагиле.
    <br />
<br />
<a onclick="$('#h1').html('ЗАПИСАТЬСЯ НА ЭКСКУРСИЮ');$('.modal_zayavka').show(100);" class="excurs">Записаться на экскурсию</a>
    <br />
<br />
<br />

    </td>
    <td class="park_img">&nbsp;</td>
  </tr>
</table>

</div>

