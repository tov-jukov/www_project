<div class="sklad" align="center" style="margin-top:100px;">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td class="exprice_img">&nbsp;</td>
    <td width="30%" style="padding:30px;background-color:#999999;color:#FFFFFF;" ><h2>А ещё, у нас самые выгодные цены</h2>
    Мы заготавливаем продукцию зимой, до начала строительного сезона, что существенно снижает стоимость.<br />
<br />
Убедитесь сами, что АвтоТранс Логистика - компания №1 в Нижнем Тагиле
    <br />
<br />
<a  onclick="$('#h1').html('ЗАЯВКА НА ПРОДУКЦИЮ');$('.modal_zayavka').show(100);" class="excurs">Заказать продукцию</a>
    <br />
<br />
<br />

    </td>
  </tr>
</table>

</div>