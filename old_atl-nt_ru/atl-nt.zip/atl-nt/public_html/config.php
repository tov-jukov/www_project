<?php

if(Q!=chr(13)) exit;




#               .---===≡≡≡  BY R.L. 2015  ≡≡≡===---.




define('URL', '');
define('NAME', '«АТЛ-НТ»');
define('GLOBALTITLE', ' - Бут, щебень, отсев, песок');
define('GLOBALKEYS', 'Щебень Нижний Тагил, купить щебень в Свердловской области, доставка щебня, доставка отсева, самосвалы в аренду, доставка торфа, бут, щебень, куплю щебень, щебень 20, щебень цена, песок, доставка самосвалами, щебень с доставкой в Екатеринбург, реализация щебня в Нижнем Тагиле');
define('GLOBALDESCR', '');

define('MAIL', 'atl-nt@mail.ru');                  // Email для уведомлений
define('FROM', 'auto@atl-nt.ru');                  // От кого, e-mail 
define('FROMNAME', 'Автоуведомления atl-nt.ru');   // От кого, тайтл
define('PHONE', '9126915700');                     // Телефон для уведомлений

define('DBNAME', 'ca41706_atlnt');
define('DBHOST', 'localhost');
define('DBUSER', 'ca41706_atlnt');
define('DBPASS', 'database981');

?>