<div align="center" style="margin-top:100px;">
<h2>Нас уже выбрали</h2>
<img src="img/dover.jpg" style="width:80%;max-width:960px;" border="0" /></div>