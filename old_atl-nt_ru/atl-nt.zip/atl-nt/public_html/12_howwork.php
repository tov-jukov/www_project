<div align="center" style="margin-top:100px;">
<h2>Так мы работаем</h2>
(Постоянным и крупным заказчикам мы предлагаем особые условия работы.)
<br />
<table border="0" cellpadding="10" cellspacing="0" style="width:100%;max-width:1280px;">
  <tr>
    <td width="25%" align="center" valign="top"><img src="img/t1.jpg" border="0" style="width:80%;" class="wow bounceIn" data-wow-delay="0.4s"/></td>
    <td width="25%" align="center" valign="top"><img src="img/t2.jpg" border="0" style="width:80%;"  class="wow bounceIn"data-wow-delay="0.8s" /></td>
    <td width="25%" align="center" valign="top"><img src="img/t3.jpg" border="0" style="width:80%;"  class="wow bounceIn" data-wow-delay="1.2s"/></td>
    <td width="25%" align="center" valign="top"><img src="img/t4.jpg" border="0" style="width:80%;"  class="wow bounceIn" data-wow-delay="1.6s"/></td>
  </tr>
  <tr>
    <td align="center" valign="top"  class="wow fadeInUp" data-wow-delay="0.4s"><strong>Заявка</strong></td>
    <td align="center" valign="top" class="wow fadeInUp" data-wow-delay="0.8s"><strong>Загрузка</strong></td>
    <td align="center" valign="top" class="wow fadeInUp" data-wow-delay="1.2s"><strong>Доставка</strong></td>
    <td align="center" valign="top" class="wow fadeInUp" data-wow-delay="1.6s"><strong>Оплата</strong></td>
  </tr>
  <tr>
    <td align="center" valign="top" class="wow fadeInUp" data-wow-delay="0.4s">Позвоните по телефону 
      <br />
      8 (3435) 92-29-92<br />
или оставте <a href="#"  onclick="$('#h1').html('ЗАЯВКА С  САЙТА');$('.modal_zayavka').show(100);return(false);" >заявку на сайте</a></td>
    <td align="center" valign="top" class="wow fadeInUp" data-wow-delay="0.8s">Обговарвиаем условия, подготавливаем машину и высылаем по Вашему адресу</td>
    <td align="center" valign="top" class="wow fadeInUp" data-wow-delay="1.2s">К Вам приходит машина и разгружается в удобном для Вас месте</td>
    <td align="center" valign="top" class="wow fadeInUp" data-wow-delay="1.6s">Расчитываемся за материал, даете нам рекомендации</td>
  </tr>
</table>


</div>