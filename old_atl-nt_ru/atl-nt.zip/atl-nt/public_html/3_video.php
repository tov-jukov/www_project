<div class="bg_vid">
<video autoplay loop muted class="bgvideo" id="bgvideo" poster="img/bg_poster.jpg">
  <source src="img/bg.ogv" type='video/ogg; codecs="theora, vorbis"'>
   <source src="img/bg.mp4" type='video/mp4; codecs="avc1.42E01E, mp4a.40.2"'>
   <source src="img/bg.webm" type='video/webm; codecs="vp8, vorbis"'>
  </video>
</div>