<div style="width:100%;margin-top:100px;" align="center">
<h1>
О продукции компании АвтоТранс Логистика
</h1>
<table border="0" cellpadding="10" cellspacing="0" style="width:100%;max-width:1280px;">
  <tr>
     <td width="30%" align="left" valign="top"><img src="img/l2.jpg" style="width:100%;" border="0"></td>
    <td align="left" valign="top">Основной продукцией нашей организации являются нерудные материалы, такие как: Бут, скала, щебень, отсев, песок и торф.<br />
      <br />
      Вся продукция проходит обязательный контроль и имеет сертификаты качества. 
      <br />
      <br />
      <table width="100%" border="0" cellpadding="10" cellspacing="0">
  <tr>
    <td align="center" valign="top"><img src="img/s1.jpg" style="width:100%;max-width:250px;" /></td>
    <td align="center" valign="top"><img src="img/s2.jpg" style="width:100%;max-width:250px;" /></td>
    <td align="center" valign="top"><img src="img/s3.jpg" style="width:100%;max-width:250px;" /></td>
    <td align="center" valign="top"><img src="img/s4.jpg" style="width:100%;max-width:250px;" /></td>
  </tr>
</table><br />
<br />

      Доставку продукции мы осуществляем как своими, так и Вашими самосвалами грузоподъемностью 10, 15, 20, 40 и 60 тонн.
      <br />
      <br />
      Погрузка осуществляется фронтальными погрузчиками на складе в Нижнем Тагиле.
<br />


    </td>
  </tr>
</table>

</div>